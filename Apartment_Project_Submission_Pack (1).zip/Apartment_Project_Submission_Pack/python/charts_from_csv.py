from pathlib import Path
import pandas as pd
import matplotlib.pyplot as plt
files=sorted(Path('output').glob('*.csv'))
if not files: raise SystemExit('No CSV files found. Run retrieve_database.py first.')
labels=[]; counts=[]
for f in files:
    labels.append(f.stem); counts.append(len(pd.read_csv(f)))
plt.figure(figsize=(10,5)); plt.bar(labels,counts)
plt.title('Record Count by Database Table'); plt.xlabel('Table'); plt.ylabel('Number of records')
plt.xticks(rotation=35,ha='right'); plt.tight_layout()
Path('output/charts').mkdir(parents=True,exist_ok=True); plt.savefig('output/charts/record_counts.png',dpi=180)
print('Saved output/charts/record_counts.png')
